# Vishal-Jarvis-AI-New

An Android Studio starter project for an advanced Bengali voice AI assistant.

## Included
- Bengali (`bn-IN`) speech recognition using Android's speech recognizer.
- Bengali text-to-speech where the device has a Bengali voice installed.
- AI chat through a configurable OpenAI-compatible Chat Completions endpoint.
- Creator identity response: "আমাকে তৈরি করেছে Vishal।"
- Phone-number dialing through the Android dialer (the user reviews and confirms the call).
- YAML configuration.

## Build
1. Install Android Studio (Jellyfish or newer) and Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Run on an Android phone (Android 8.0 / API 26 or newer).
5. Grant microphone permission when prompted.
6. Tap **AI সেটিংস** and enter a compatible API endpoint, model name, and API key.

## Important
- Do not publish an API key inside a public APK. This starter stores the key in app preferences for local testing only. For production, use a secure backend that keeps the provider key server-side.
- The phone feature opens the Android dialer; it does not silently place calls.
- Contact-name calling, app launching, flashlight control, reminders, background wake-word listening, and deeper device controls are not implemented yet.
- Bengali speech recognition/TTS availability depends on Android speech services and installed language data.
- This is source code, not a prebuilt APK. Build it in Android Studio.

## Next development milestones
1. Secure backend proxy for AI requests.
2. Contact picker + contact lookup with runtime permission.
3. CameraManager flashlight control.
4. Alarm/notification/reminder scheduling.
5. App launcher and accessibility-safe device actions.
6. Persistent conversation history and optional wake-word service.
