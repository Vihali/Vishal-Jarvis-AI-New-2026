package com.vishal.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val recognizer = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) { input.setText(spoken); handleCommand(spoken) }
        }
    }
    private val audioPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListening() else say("মাইক্রোফোন ব্যবহারের অনুমতি দেওয়া হয়নি।")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
            setBackgroundColor(0xFF101820.toInt())
        }
        val heading = TextView(this).apply {
            text = "VISHAL JARVIS AI\nআপনার বাংলা AI সহকারী"
            textSize = 23f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
        }
        chat = TextView(this).apply {
            text = "নমস্কার! আমি Jarvis। কী সাহায্য করতে পারি?\n"
            textSize = 16f; setTextColor(0xFFE8EEF2.toInt()); setPadding(0, 24, 0, 24)
        }
        val scroll = ScrollView(this).apply { addView(chat) }
        input = EditText(this).apply {
            hint = "এখানে লিখুন বা মাইক্রোফোনে বলুন"; setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFB0BEC5.toInt())
        }
        val send = Button(this).apply { text = "পাঠান"; setOnClickListener { handleCommand(input.text.toString()) } }
        val mic = Button(this).apply { text = "🎙 কথা বলুন"; setOnClickListener {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListening()
            else audioPermission.launch(Manifest.permission.RECORD_AUDIO)
        } }
        val settings = Button(this).apply { text = "AI সেটিংস"; setOnClickListener { showSettings() } }
        layout.addView(heading)
        layout.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        layout.addView(input)
        layout.addView(send)
        layout.addView(mic)
        layout.addView(settings)
        setContentView(layout)
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "বলুন, কী করতে হবে?")
        }
        try { recognizer.launch(intent) } catch (_: Exception) { say("এই ডিভাইসে Speech Recognition চালু করা যাচ্ছে না।") }
    }

    private fun handleCommand(raw: String) {
        val command = raw.trim()
        if (command.isEmpty()) return
        addLine("আপনি: $command")
        input.setText("")
        val lower = command.lowercase(Locale.ROOT)
        when {
            lower.contains("কে বানিয়েছে") || lower.contains("who created") || lower.contains("তোমাকে কে") ->
                say("আমাকে তৈরি করেছে Vishal।")
            lower.contains("ফোন কর") || lower.contains("কল কর") || lower.contains("call ") -> {
                val number = Regex("[+]?\\d[\\d -]{5,}").find(command)?.value?.replace(" ", "")?.replace("-", "")
                if (number != null) {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
                    say("নম্বরটি ডায়ালারে খুলে দিয়েছি। কল করার আগে নম্বরটি দেখে নিন।")
                } else say("ফোন নম্বরটি লিখে বলুন। আপাতত নম্বর দিয়ে ডায়াল করা যায়; কন্ট্যাক্ট নাম দিয়ে কল করার সুবিধা পরের ধাপে যোগ করতে হবে।")
            }
            lower.contains("ফ্ল্যাশ") || lower.contains("flashlight") ->
                say("ফ্ল্যাশলাইট নিয়ন্ত্রণের জন্য এই প্রাথমিক সংস্করণে ডিভাইস-নির্দিষ্ট Camera API যোগ করা বাকি।")
            else -> askAI(command)
        }
    }

    private fun askAI(prompt: String) {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val endpoint = prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions") ?: ""
        val key = prefs.getString("api_key", "") ?: ""
        val model = prefs.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini"
        if (key.isBlank()) {
            say("AI Brain চালাতে আগে AI সেটিংসে API endpoint এবং API key দিন। ফোনের সাধারণ ডায়ালার কমান্ড API ছাড়াও কাজ করে।")
            return
        }
        addLine("Jarvis: ভাবছি…")
        scope.launch {
            val answer = withContext(Dispatchers.IO) {
                AIEngine.chat(endpoint, key, model, prompt)
            }
            say(answer)
        }
    }

    private fun showSettings() {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 8) }
        val endpoint = EditText(this).apply { hint = "API endpoint"; setText(prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions")) }
        val model = EditText(this).apply { hint = "Model"; setText(prefs.getString("model", "gpt-4o-mini")) }
        val key = EditText(this).apply { hint = "API key"; setText(prefs.getString("api_key", "")); inputType = 0x81 }
        box.addView(endpoint); box.addView(model); box.addView(key)
        AlertDialogBuilder.show(this, box) {
            prefs.edit().putString("endpoint", endpoint.text.toString().trim())
                .putString("model", model.text.toString().trim())
                .putString("api_key", key.text.toString().trim()).apply()
            say("AI সেটিংস সংরক্ষণ করা হয়েছে।")
        }
    }

    private fun addLine(line: String) { chat.append("\n$line\n") }
    private fun say(message: String) {
        addLine("Jarvis: $message")
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("bn", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                tts.setLanguage(Locale("en", "IN"))
        }
    }
    override fun onDestroy() { scope.cancel(); if (::tts.isInitialized) tts.shutdown(); super.onDestroy() }
}
