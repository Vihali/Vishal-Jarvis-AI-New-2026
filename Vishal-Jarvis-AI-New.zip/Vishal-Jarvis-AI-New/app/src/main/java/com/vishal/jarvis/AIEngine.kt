package com.vishal.jarvis

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object AIEngine {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    fun chat(endpoint: String, apiKey: String, model: String, prompt: String): String {
        return try {
            val system = "তোমার নাম Jarvis। তোমার নির্মাতা Vishal। ডিফল্ট ভাষা পশ্চিমবঙ্গের স্বাভাবিক ভারতীয় বাংলা। সহজ, স্বাভাবিক ও সহায়কভাবে উত্তর দাও।"
            val messages = JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", prompt))
            val body = JSONObject().put("model", model).put("messages", messages)
                .toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder().url(endpoint).addHeader("Authorization", "Bearer $apiKey")
                .post(body).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return "AI সার্ভারে সমস্যা হয়েছে: HTTP ${response.code}। API key, endpoint এবং model যাচাই করুন।"
                val json = JSONObject(response.body?.string().orEmpty())
                json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
        } catch (e: Exception) {
            "AI-এর সঙ্গে সংযোগ করা যায়নি। ইন্টারনেট, API endpoint এবং API key পরীক্ষা করুন।"
        }
    }
}
