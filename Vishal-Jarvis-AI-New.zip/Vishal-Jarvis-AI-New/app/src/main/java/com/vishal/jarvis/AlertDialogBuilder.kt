package com.vishal.jarvis

import android.content.Context
import android.app.AlertDialog
import android.widget.LinearLayout

object AlertDialogBuilder {
    fun show(context: Context, view: LinearLayout, onSave: () -> Unit) {
        AlertDialog.Builder(context)
            .setTitle("Jarvis AI Settings")
            .setView(view)
            .setPositiveButton("Save") { _, _ -> onSave() }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
